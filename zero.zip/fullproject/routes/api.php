<?php

use App\Http\Controllers\Api\VoiceWebhookController;
use App\Http\Controllers\Api\WhatsAppWebhookController;
use Illuminate\Support\Facades\Route;

// WhatsApp Cloud API webhook — Meta calls these directly, so they're outside the
// 'web' middleware group (no CSRF) but the controller verifies the signature itself.
Route::get('/webhooks/whatsapp', [WhatsAppWebhookController::class, 'verify']);
Route::post('/webhooks/whatsapp', [WhatsAppWebhookController::class, 'receive']);

// Twilio Voice webhooks (Milestone 4) — Twilio calls these directly, same as above.
// TWILIO_TWIML_URL and TWILIO_STATUS_CALLBACK_URL in .env must point here.
Route::match(['get', 'post'], '/webhooks/voice/twiml', [VoiceWebhookController::class, 'twiml']);
Route::post('/webhooks/voice/status', [VoiceWebhookController::class, 'status']);
