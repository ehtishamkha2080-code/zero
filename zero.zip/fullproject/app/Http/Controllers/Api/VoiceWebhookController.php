<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Services\Voice\VoiceCallService;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

/**
 * Receives Twilio's callbacks for calls placed by VoiceCallService::initiateCall().
 * Both endpoints are called directly by Twilio, not by the browser — no auth
 * middleware, same pattern as WhatsAppWebhookController.
 */
class VoiceWebhookController extends Controller
{
    public function __construct(protected VoiceCallService $voice) {}

    /**
     * GET/POST /api/webhooks/voice/twiml — Twilio fetches this once the contact
     * answers the call, expecting TwiML back. Bridges the call to the agent's
     * phone (identified by ?user_id=, appended in initiateCall) so the agent and
     * contact end up talking to each other.
     */
    public function twiml(Request $request): Response
    {
        $user = User::find($request->query('user_id'));

        $twiml = $user && $user->phone
            ? '<Response><Dial callerId="'.e($this->voice->callerId()).'">'.e($user->phone).'</Dial></Response>'
            : '<Response><Say>Sorry, the agent could not be reached. Please try again later.</Say><Hangup/></Response>';

        return response('<?xml version="1.0" encoding="UTF-8"?>'."\n".$twiml, 200)
            ->header('Content-Type', 'text/xml');
    }

    /**
     * POST /api/webhooks/voice/status — Twilio's status-callback, fired as the
     * call progresses and once it ends. Updates the matching VoiceCall record.
     */
    public function status(Request $request): Response
    {
        $this->voice->logCallCompletion($request->all());

        return response('', 204);
    }
}
