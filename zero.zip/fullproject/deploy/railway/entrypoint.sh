#!/usr/bin/env bash
set -e

# Railway runs this same image for multiple services (web, queue worker,
# scheduler) with different start commands. Only set up nginx when this
# container is actually serving HTTP (i.e. the default supervisord CMD).
if [[ "$1" == "supervisord" ]]; then
    : "${PORT:=8080}"
    export PORT

    envsubst '${PORT}' < /etc/nginx/templates/default.conf.template > /etc/nginx/conf.d/default.conf

    nginx -t
fi

# Run pending migrations and cache config/routes/views for production
# performance — safe to run on every boot since both are idempotent (already
# applied migrations are skipped; caching just rebuilds from source each
# time). Skipped if APP_KEY isn't set yet (first deploy, before
# `php artisan key:generate`/DB env vars exist). Only runs for the web
# service (guarded by the same "$1" == "supervisord" check as above) — the
# worker/scheduler services use a different start command and would
# otherwise race to migrate at boot too.
if [[ "$1" == "supervisord" ]] && [ -n "$APP_KEY" ]; then
    php artisan migrate --force || true
    php artisan config:cache || true
    php artisan route:cache || true
    php artisan view:cache || true
fi

exec "$@"
